void LCD_GPIO_Init(void)
{
	......
//Init the GPIOs for LCD	
}
void LCD_RESET(void)
{
	LCD_RST_CLR;
	delay_ms(100);	
	LCD_RST_SET;
	delay_ms(50);
}
void LCD_Init(void)
{
	//LCD_GPIO_Init();//Init the GPIOs for LCD
	//LCD_RESET();//You should ResetLCD before Init.

		//************* Start Initial Sequence **********//		
	/*******power on*******/
	LCD_WriteReg(0x15,0x0030);
	LCD_WriteReg(0x9A,0x0010);
	LCD_WriteReg(0x11,0x0020);
	LCD_WriteReg(0x10,0x3428);
	LCD_WriteReg(0x12,0x0002);
	LCD_WriteReg(0x13,0x1046);
	delay_us(40000);//40ms
	LCD_WriteReg(0x12,0x0012);
	delay_us(40000);//40ms
	LCD_WriteReg(0x10,0x3420);
	LCD_WriteReg(0x13,0x3046);
	delay_us(70000);//70ms

	/******gamma setting******/
	LCD_WriteReg(0x30,0x0000);
	LCD_WriteReg(0x31,0x0402);
	LCD_WriteReg(0x32,0x0307);
	LCD_WriteReg(0x33,0x0304);
	LCD_WriteReg(0x34,0x0004);
	LCD_WriteReg(0x35,0x0401);
	LCD_WriteReg(0x36,0x0707);
	LCD_WriteReg(0x37,0x0305);
	LCD_WriteReg(0x38,0x0610);
	LCD_WriteReg(0x39,0x0610);

	/********display mode******/
	LCD_WriteReg(0x01,0x0100);
	LCD_WriteReg(0x02,0x0300);
	LCD_WriteReg(0x03,0x1030);
	LCD_WriteReg(0x08,0x0808);
	LCD_WriteReg(0x0A,0x0008);
	LCD_WriteReg(0x60,0x2700);
	LCD_WriteReg(0x61,0x0001);

	LCD_WriteReg(0x90,0x013E);
	LCD_WriteReg(0x92,0x0100);
	LCD_WriteReg(0x93,0x0100);
	LCD_WriteReg(0xA0,0x3000);
	LCD_WriteReg(0xA3,0x0010);

	/*******display on*******/
	LCD_WriteReg(0x07,0x0001);
	LCD_WriteReg(0x07,0x0021);
	LCD_WriteReg(0x07,0x0023);
	LCD_WriteReg(0x07,0x0033);
	LCD_WriteReg(0x07,0x0133);
	LCD_WR_REG(0x22);
}


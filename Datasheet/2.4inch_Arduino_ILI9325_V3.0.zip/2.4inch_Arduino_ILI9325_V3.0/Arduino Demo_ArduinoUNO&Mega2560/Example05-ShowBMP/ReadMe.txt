Attention:
This Example only support the Arduino UNO board,do not support Mega2560,Because they use different SPI IO Pins.

How to use:
1)Copy the Images in floder "PIC" to your SD-card root directory,
2)Insert your SD-card into the SD-socket of 2.4"Arduino LCD Module.
3)Power on. 